Local onde ficam os arquivos j� transmitidos pelo transbio
