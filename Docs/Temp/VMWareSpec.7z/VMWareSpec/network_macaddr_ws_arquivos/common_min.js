initNav=function(){
var _1=document.getElementById("primary-navigation");
if(_1){
var _2=_1.getElementsByTagName("li");
for(var i=0;i<_2.length;i++){
var _4=_2[i].getElementsByTagName("ul");
if(_4.length){
_2[i].onmouseover=function(){
this.className+=" hover";
};
_2[i].onmouseout=function(){
this.className=this.className.replace("hover","");
};
}
}
}
var _1=document.getElementById("language");
if(_1!=null){
var _2=_1.getElementsByTagName("li");
for(var i=0;i<_2.length;i++){
var _4=_2[i].getElementsByTagName("ul");
if(_4.length){
_2[i].onmouseover=function(){
this.className+=" hover";
};
_2[i].onmouseout=function(){
this.className=this.className.replace("hover","");
};
}
}
}
};
if(window.addEventListener){
window.addEventListener("load",initNav,false);
}else{
if(window.attachEvent){
window.attachEvent("onload",initNav);
}
}
function searchfield_clear(){
if(document.f.q.value!=""){
document.f.q.value="";
}
};
function searchfield_blur(){
if(document.f.q.value==""){
document.f.q.value=(document.gs.q.value.length)?document.gs.q.value:"";
}
};
function vmemail(_5,_6,_7,_8){
if(!_7){
var _7="vmware.com";
}
if(!_6){
var _6=" ";
}
if(!_8){
var _8=" ";
}
eval("location.href='mailto:"+_5+"@"+_7+"?subject="+_6+"&body="+_8+"'");
};
function popup(_9,_a,w,h,_d,_e,_f,_10){
var _11="";
if(_d){
_d="yes";
}else{
_d="no";
}
if(_e){
_e="yes";
}else{
_e="no";
}
if(_f){
_f="yes";
}else{
_f="no";
}
if(!_10){
_10="no";
}else{
_10="yes";
}
_11="width="+w+",height="+h+",directories=no,location="+_10+",menubar="+_10+",resizable="+_e+",scrollbars="+_d+",status="+_f+",toolbar="+_10;
var _12=window.open(_9,_a,_11);
_12.focus();
};
function showLayer(lyr){
document.getElementById(currentLayer).className="hide";
document.getElementById(lyr).className="show";
currentLayer=lyr;
};
function showTab(lyr){
document.getElementById(currentTab).className="taboff";
document.getElementById(lyr).className="tabon";
currentTab=lyr;
};
function getParameter(_15){
var url=window.location.href;
var _17=url.indexOf("?");
if(_17!=-1){
var _18=url.substr(_17+1);
var _19=_18.indexOf(_15);
if(_19!=-1){
paramToEnd=_18.substr(_19+_15.length+1);
var _1a=paramToEnd.indexOf("&");
if(_1a==-1){
return paramToEnd;
}else{
return paramToEnd.substr(0,_1a);
}
}
}
};
function handleSubmit(_1b){
var _1c=_1b.getElementsByTagName("input");
for(i=0;i<_1c.length;i++){
if(_1c[i].type.toLowerCase()=="submit"){
_1c[i].disabled=true;
}
}
};

